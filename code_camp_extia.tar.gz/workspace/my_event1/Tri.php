<?php session_start(); ?>
<!DOCTYPE html5>
<html>
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<form method='GET'>
			<button id='bouton' name='button' value='Toutes' style="background-color: #FFF;">Toutes</button>
			<button id='bouton' name='button' value='Aix-en-Provence' style="background-color: #FFF;">Aix-en-Provence</button>
			<button id='bouton' name='button' value='Bruxelles' style="background-color: #FFF;">Bruxelles</button>
			<button id='bouton' name='button' value='Grenoble' style="background-color: #FFF;">Grenoble</button>
			<button id='bouton' name='button' value='Lausanne' style="background-color: #FFF;">Lausanne</button>
			<button id='bouton' name='button' value='Lille' style="background-color: #FFF;">Lille</button>
			<button id='bouton' name='button' value='Lyon' style="background-color: #FFF;">Lyon</button>
			<button id='bouton' name='button' value='Paris' style="background-color: #FFF;">Paris</button>
			<button id='bouton' name='button' value='Sophia-Antipolis' style="background-color: #FFF;">Sophia-Antipolis</button>
		</form>
		<?php
			$conn = mysqli_connect('localhost', 'anniba_c', '', 'Test');
			if ($_GET['button'] != 'Toutes')
			{
				$req = mysqli_query($conn, "SELECT * FROM L_Eve WHERE Nom_Ville = '".$_GET['button']."'");
			}
			else
			{
				$req = mysqli_query($conn, "SELECT * FROM L_Eve");
			}
			if ($req)
				{
					while ($data = mysqli_fetch_assoc($req))
					{
						echo "<img src=".$data['Nom_Img']."> ".$data['Nom_Evenement']." ".$data['Nom_Ville']."<br>";
					}
				}

		?>
		<script type="text/javascript">
			
		</script>

	</body>
</html>