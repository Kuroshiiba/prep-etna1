create database my_event;

use my_event;

create table user
(
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(100),
    prenom VARCHAR(100),
    email VARCHAR(100),
    login VARCHAR(100),
    mdp VARCHAR(100)
);

create table even
(
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    type INT,
    nom VARCHAR(100),
    description VARCHAR(1000),
    date_even DATE,
    ville VARCHAR(100),
    pays VARCHAR(100),
    heure_debut TIME,
    heure_fin TIME,
    image VARCHAR(100)
);

create table contact
(
    nom VARCHAR(100),
    email VARCHAR(50),
    message VARCHAR(10000)
);