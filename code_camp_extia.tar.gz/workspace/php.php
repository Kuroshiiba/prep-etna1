<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <title>INSCRIPTION</title>
    <link href="stylesheet.css" rel="stylesheet">
    
</head>
<h1>INSCRIPTION...</h1>
<form id="submit" name ="submit" method="post">
    <p>Login : </p>
    <input type="text" name="login"/>
    <p>Email : </p>
    <input type="email" name="email"/>
    <p>Mot de passe : </p>
    <input type="password" name="pwd"/>
    <p>Nom : </p>
    <input type="text" name="name"/>
    <p>Numero de telephone : </p>
    <input type="number" name="tel"/><br><br>
    
    <input type="submit" id="submit" name="submit" value="Validez l'inscription"/><br>
</form>

<h1>...OU CONNEXION</h1>
<form id="connexion" method="post">
    <p>Email : </p>
    <input type="email" name="email2"/>
     <p>Mot de passe : </p>
    <input type="password" name="pwd2"/><br><br>
    <input type="submit" name="connexion" value="connexion"/><br>


<?php
    if($_POST['submit'])
    {
        if (!empty($_POST['login']) && !empty($_POST['email']) && !empty($_POST['pwd']) && !empty($_POST['name']) && !empty($_POST['tel']))
            {
                if (isset($_POST['login']))
                    {
                        $_POST['login'] = htmlspecialchars($_POST['login']);
                        if (preg_match("/^[a-zA-Z]*[0-9]*?[^éèàê]$/", $_POST['login']))
                            {

                            $infos = array(
                            "login" => $_POST['login'],
                            "email" => $_POST['email'],
                            "pwd" => $_POST['pwd'],
                            "name" => $_POST['name'],
                            "tel" => $_POST['tel']
                            );
                            file_put_contents("users.json",json_encode($infos), FILE_APPEND);
                            }
                        else 
                            echo "Vous devez remplir chaque champs !";
                }
        }
    }
    
    
    if(!empty($_POST['connexion']))
    {
      $fichier_json = file_get_contents("users.json");
      $json = json_decode($fichier_json, true);
      if(($_POST['email2'] == $json['email']) && ($_POST['pwd2'] == $json['pwd']))
      {
        echo "Vous êtes connecté !\n";
        if ($_SESSION['email2'] = $json['email'] && $_SESSION['pwd2'] = $json['pwd'] )
            { 
                echo "Bienvenue !\n";
                echo "<input type='submit' name='deconnexion' value='Deconnexion'/>";
                    if ($_POST['deconnexion'])
                        session_unset();
            }
        }
        else if (($_POST['email2'] != $json['email']) || ($_POST['pwd2'] != $json['pwd']))
          echo "Mot de passe ou email incorrect.\n";
    }

?>

<?php
    $i = 0;
    $alphab = array(
    'a'=> 'M',
    'b'=> 'N',
    'c'=> 'B', 
    'd'=> 'V',
    'e'=> 'C', 
    'f'=> 'X',
    'g'=> 'Z', 
    'h'=> 'L', 
    'i'=> 'K', 
    'j'=> 'J', 
    'k'=> 'H', 
    'l'=> 'G', 
    'm'=> 'F', 
    'n'=> 'D', 
    'o'=> 'S', 
    'p'=> 'A', 
    'q'=> 'P', 
    'r'=> 'O', 
    's'=> 'I', 
    't'=> 'U', 
    'u'=> 'Y', 
    'v'=> 'T', 
    'w'=> 'R', 
    'x'=> 'E', 
    'y'=> 'W', 
    'z'=> 'Q');        
  //  if(($_POST['email2'] == $json['email']) && ($_POST['pwd2'] == $json['pwd']))
    //{
        preg_match_all("/[a-z]/", "test", $mdp);
        while($mdp[$i] != '\0')
        {
            echo $mdp[$i];
            $i++;
        }
        
    //}
    
    
    
     
?>

</html>